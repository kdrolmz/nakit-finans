import {generateRegistrationOptions,verifyRegistrationResponse,generateAuthenticationOptions,verifyAuthenticationResponse,type RegistrationResponseJSON,type AuthenticationResponseJSON} from '@simplewebauthn/server';
import {emptyStore,validStore} from '../app/sync-model';

export interface Env { DB:D1Database; ASSETS:Fetcher; APP_ORIGIN:string; SETUP_HASH:string }
type Session={token_hash:string;expires_at:number;authenticated_at:number};
type Challenge={challenge:string;purpose:string;session_hash:string|null};
type Key={id:string;public_key:string;counter:number;transports:string};
const sessionName='__Host-nakit-session',challengeName='__Host-nakit-challenge';
const now=()=>Math.floor(Date.now()/1000);
const token=()=>to64(crypto.getRandomValues(new Uint8Array(32)));
function to64(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
function from64(s:string){return Uint8Array.from(atob(s.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));}
export async function hash(s:string){return to64(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))));}
function cookie(name:string,value:string,age:number){return `${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;}
function readCookie(req:Request,name:string){return req.headers.get('cookie')?.split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1)||'';}
function json(data:unknown,status=200,cookies:string[]=[]){const headers=new Headers({'Content-Type':'application/json','Cache-Control':'no-store, private','Vary':'Cookie'});cookies.forEach(c=>headers.append('Set-Cookie',c));return new Response(JSON.stringify(data),{status,headers});}
class HttpError extends Error{constructor(message:string,public status=400){super(message);}}
async function session(req:Request,env:Env){const raw=readCookie(req,sessionName);if(!/^[\w-]{43}$/.test(raw))return null;return env.DB.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?').bind(await hash(raw),now()).first<Session>();}
async function newSession(){const raw=token();return {raw,hashed:await hash(raw),expires:now()+30*86400};}
async function body(req:Request,max=24_000){if(!req.headers.get('content-type')?.startsWith('application/json'))throw new HttpError('JSON gerekli.',415);const text=await req.text();if(text.length>max)throw new HttpError('Kayıt çok büyük.',413);try{return JSON.parse(text);}catch{throw new HttpError('Geçersiz istek.');}}
async function throttle(req:Request,env:Env){const ip=req.headers.get('CF-Connecting-IP')||'local',minute=Math.floor(now()/60);const id=await hash(ip+':'+minute);const row=await env.DB.prepare('INSERT INTO throttle(id,count,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=count+1 RETURNING count').bind(id,now()+120).first<{count:number}>();if(!row||row.count>20)throw new HttpError('Çok fazla deneme. Bir dakika sonra yeniden dene.',429);}
async function consume(req:Request,env:Env){const id=readCookie(req,challengeName);const c=await env.DB.prepare('DELETE FROM challenges WHERE id=? AND expires_at>? RETURNING challenge,purpose,session_hash').bind(id,now()).first<Challenge>();if(!c)throw new HttpError('Giriş isteğinin süresi doldu. Yeniden dene.');return c;}
async function challenge(env:Env,value:string,purpose:string,sessionHash:string|null=null){const id=token();await env.DB.prepare('INSERT INTO challenges(id,challenge,purpose,session_hash,expires_at) VALUES(?,?,?,?,?)').bind(id,value,purpose,sessionHash,now()+300).run();return cookie(challengeName,id,300);}
const insertSession=(env:Env,s:{hashed:string;expires:number})=>env.DB.prepare('INSERT INTO sessions(token_hash,expires_at,authenticated_at) VALUES(?,?,?)').bind(s.hashed,s.expires,now());

async function api(req:Request,env:Env){
 const url=new URL(req.url),path=url.pathname;
 if(!env.APP_ORIGIN||url.origin!==env.APP_ORIGIN)throw new HttpError('Uygulama adresi doğrulanamadı.',503);
 if(!['GET','POST','PUT'].includes(req.method))throw new HttpError('Yöntem desteklenmiyor.',405);
 if(req.method!=='GET'&&req.headers.get('origin')!==env.APP_ORIGIN)throw new HttpError('Geçersiz kaynak.',403);
 const s=await session(req,env);
 if(path==='/api/auth/status'&&req.method==='GET'){
  const owner=await env.DB.prepare('SELECT id FROM owner WHERE id=1').first();
  return json({authenticated:!!s,configured:!!owner});
 }
 if(path.startsWith('/api/auth/')&&req.method==='POST'){
  await throttle(req,env);
  const data=await body(req),rpID=new URL(env.APP_ORIGIN).hostname;
  if(path==='/api/auth/register/options'){
   const owner=await env.DB.prepare('SELECT id FROM owner WHERE id=1').first();
   if(owner&&!s)throw new HttpError('Önce hesabına giriş yap.',401);
   if(owner&&s&&now()-s.authenticated_at>600)throw new HttpError('Yeni anahtar eklemek için çıkış yapıp yeniden giriş yap.',403);
   if(!owner&&(!env.SETUP_HASH||typeof data.setupCode!=='string'||await hash(data.setupCode.trim())!==env.SETUP_HASH))throw new HttpError('Kurulum kodu doğru değil.',403);
   const keys=await env.DB.prepare('SELECT id FROM passkeys').all<{id:string}>();
   if(keys.results.length>=10)throw new HttpError('En fazla 10 geçiş anahtarı eklenebilir.');
   const options=await generateRegistrationOptions({rpName:'Nakit',rpID,userName:'Kişisel finans hesabım',userID:new TextEncoder().encode('nakit-owner'),attestationType:'none',excludeCredentials:keys.results.map(k=>({id:k.id})),authenticatorSelection:{residentKey:'required',userVerification:'required'},supportedAlgorithmIDs:[-7,-257]});
   return json(options,200,[await challenge(env,options.challenge,owner?'add':'setup',s?.token_hash)]);
  }
  if(path==='/api/auth/register/verify'){
   const c=await consume(req,env);if(!['setup','add'].includes(c.purpose))throw new HttpError('Geçersiz doğrulama.');
   if(c.purpose==='add'&&(!s||s.token_hash!==c.session_hash||now()-s.authenticated_at>600))throw new HttpError('Yeniden giriş yap.',401);
   const result=await verifyRegistrationResponse({response:data.response as RegistrationResponseJSON,expectedChallenge:c.challenge,expectedOrigin:env.APP_ORIGIN,expectedRPID:rpID,requireUserVerification:true});
   if(!result.verified||!result.registrationInfo)throw new HttpError('Geçiş anahtarı doğrulanamadı.');
   const {credential}=result.registrationInfo,login=await newSession(),recovery=c.purpose==='setup'?token():null;
   const statements=[];
   if(recovery)statements.push(env.DB.prepare('INSERT INTO owner(id,recovery_hash,created_at) VALUES(1,?,?)').bind(await hash(recovery),now()));
   statements.push(env.DB.prepare('INSERT INTO passkeys(id,public_key,counter,transports,created_at) VALUES(?,?,?,?,?)').bind(credential.id,to64(credential.publicKey),credential.counter,JSON.stringify(credential.transports||[]),now()),insertSession(env,login));
   await env.DB.batch(statements);
   return json({ok:true,recoveryCode:recovery},200,[cookie(sessionName,login.raw,30*86400),cookie(challengeName,'',0)]);
  }
  if(path==='/api/auth/login/options'){
   const options=await generateAuthenticationOptions({rpID,userVerification:'required'});
   return json(options,200,[await challenge(env,options.challenge,'login')]);
  }
  if(path==='/api/auth/login/verify'){
   const c=await consume(req,env);if(c.purpose!=='login')throw new HttpError('Geçersiz giriş isteği.');
   const response=data.response as AuthenticationResponseJSON;
   if(!response||typeof response.id!=='string')throw new HttpError('Geçersiz anahtar.');
   const key=await env.DB.prepare('SELECT * FROM passkeys WHERE id=?').bind(response.id).first<Key>();
   if(!key)throw new HttpError('Bu anahtar hesabına ait değil.',401);
   const result=await verifyAuthenticationResponse({response,expectedChallenge:c.challenge,expectedOrigin:env.APP_ORIGIN,expectedRPID:rpID,credential:{id:key.id,publicKey:from64(key.public_key),counter:key.counter},requireUserVerification:true});
   if(!result.verified)throw new HttpError('Giriş doğrulanamadı.',401);
   const login=await newSession();
   await env.DB.batch([env.DB.prepare('UPDATE passkeys SET counter=MAX(counter,?) WHERE id=?').bind(result.authenticationInfo.newCounter,key.id),insertSession(env,login)]);
   return json({ok:true},200,[cookie(sessionName,login.raw,30*86400),cookie(challengeName,'',0)]);
  }
  if(path==='/api/auth/recover'){
   if(typeof data.code!=='string'||!/^[-\w]{43}$/.test(data.code.trim()))throw new HttpError('Kurtarma kodu doğru değil.',401);
   const recovery=token(),oldHash=await hash(data.code.trim()),newHash=await hash(recovery),login=await newSession();
   // A single transaction rotates recovery, revokes lost credentials/sessions, and grants the new session.
   const results=await env.DB.batch([
    env.DB.prepare('UPDATE owner SET recovery_hash=? WHERE id=1 AND recovery_hash=?').bind(newHash,oldHash),
    env.DB.prepare('DELETE FROM sessions WHERE EXISTS(SELECT 1 FROM owner WHERE id=1 AND recovery_hash=?)').bind(newHash),
    env.DB.prepare('DELETE FROM passkeys WHERE EXISTS(SELECT 1 FROM owner WHERE id=1 AND recovery_hash=?)').bind(newHash),
    env.DB.prepare('INSERT INTO sessions(token_hash,expires_at,authenticated_at) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM owner WHERE id=1 AND recovery_hash=?)').bind(login.hashed,login.expires,now(),newHash)
   ]);
   if(!results[0].meta.changes)throw new HttpError('Kurtarma kodu doğru değil veya daha önce kullanılmış.',401);
   return json({ok:true,recoveryCode:recovery},200,[cookie(sessionName,login.raw,30*86400)]);
  }
  if(path==='/api/auth/logout'){
   if(s)await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(s.token_hash).run();
   return json({ok:true},200,[cookie(sessionName,'',0),cookie(challengeName,'',0)]);
  }
 }
 if(path==='/api/finance'){
  if(!s)throw new HttpError('Oturumun kapandı. Geçiş anahtarınla yeniden giriş yap.',401);
  if(req.method==='GET'){
   const row=await env.DB.prepare("SELECT data,revision,updated_at FROM finance_accounts WHERE user_id='owner'").first<{data:string;revision:number;updated_at:string}>();
   return json({store:row?JSON.parse(row.data):emptyStore(),revision:row?.revision??0,updatedAt:row?.updated_at??null});
  }
  if(req.method==='PUT'){
   const data=await body(req,2_000_000);if(!validStore(data.store)||!Number.isSafeInteger(data.revision)||data.revision<0)throw new HttpError('Geçersiz kayıt.');
   const updatedAt=new Date().toISOString();
   const result=data.revision===0?await env.DB.prepare("INSERT INTO finance_accounts(user_id,data,revision,updated_at) VALUES('owner',?,1,?) ON CONFLICT(user_id) DO NOTHING").bind(JSON.stringify(data.store),updatedAt).run():await env.DB.prepare("UPDATE finance_accounts SET data=?,revision=revision+1,updated_at=? WHERE user_id='owner' AND revision=?").bind(JSON.stringify(data.store),updatedAt,data.revision).run();
   if(!result.meta.changes)return json({error:'Başka cihazda güncellendi.'},409);
   return json({store:data.store,revision:data.revision+1,updatedAt});
  }
 }
 throw new HttpError('Bulunamadı.',404);
}

export default {async fetch(req:Request,env:Env,ctx:ExecutionContext){
 let response:Response;
 try{response=new URL(req.url).pathname.startsWith('/api/')?await api(req,env):await env.ASSETS.fetch(req);}
 catch(e){response=e instanceof HttpError?json({error:e.message},e.status):json({error:'İşlem doğrulanamadı. Yeniden dene.'},400);}
 // No request bodies, passkey responses, recovery codes, or finance data are logged.
 if(Math.random()<0.02)ctx.waitUntil(env.DB.batch(['sessions','challenges','throttle'].map(table=>env.DB.prepare(`DELETE FROM ${table} WHERE expires_at<?`).bind(now()))).catch(()=>{}));
 const headers=new Headers(response.headers);
 headers.set('X-Content-Type-Options','nosniff');headers.set('Referrer-Policy','no-referrer');headers.set('X-Frame-Options','DENY');headers.set('Strict-Transport-Security','max-age=31536000');
 headers.set('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self' https://scanner.tradingview.com https://finans.truncgil.com; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'");
 headers.set('Permissions-Policy','camera=(), microphone=(), geolocation=()');
 if(!new URL(req.url).pathname.startsWith('/assets/'))headers.set('Cache-Control','no-store');
 return new Response(response.body,{status:response.status,headers});
}};
