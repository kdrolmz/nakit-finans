CREATE TABLE owner (id INTEGER PRIMARY KEY CHECK(id=1), recovery_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE passkeys (id TEXT PRIMARY KEY, public_key TEXT NOT NULL, counter INTEGER NOT NULL, transports TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE sessions (token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL, authenticated_at INTEGER NOT NULL);
CREATE TABLE challenges (id TEXT PRIMARY KEY, challenge TEXT NOT NULL, purpose TEXT NOT NULL, session_hash TEXT, expires_at INTEGER NOT NULL);
CREATE TABLE throttle (id TEXT PRIMARY KEY, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE finance_accounts (user_id TEXT PRIMARY KEY, data TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
