import {readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const destination=process.argv[2]||fileURLToPath(new URL('../../../outputs/index.html',import.meta.url));
writeFileSync(destination,readFileSync(new URL('launcher.html',import.meta.url)));
console.log('Synced app launcher: '+destination);
