import {readFileSync,writeFileSync} from 'node:fs';
const manifest=JSON.parse(readFileSync(new URL('../../brand-assets/manifest.json',import.meta.url),'utf8'));
const aliases={'Ziraat':'Ziraat Bankası','Vakıfbank':'VakıfBank','Denizbank':'DenizBank','YouTube':'YouTube Premium','HBO/Max':'Max / HBO','Canva':'Canva Pro','ChatGPT':'ChatGPT Plus','Adobe':'Adobe CC','iCloud':'iCloud+','Microsoft':'Microsoft 365','Gain':'GAIN','Mubi':'MUBI','TOD/beIN':'TOD','Allianz':'Allianz Yaşam','beIN':'beIN Connect'};
const mime={png:'image/png',svg:'image/svg+xml',ico:'image/x-icon',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp'};
const logos={},sources={};
for(const [name,asset] of Object.entries(manifest)){const key=aliases[name]||name;if(!asset.file)throw Error(name+' missing');const bytes=readFileSync(asset.file);const ext=asset.file.split('.').pop();logos[key]='data:'+mime[ext]+';base64,'+bytes.toString('base64');sources[key]=asset.sourceUrl;}
for(const [name,source] of Object.entries({'Türk Telekom İnternet':'Türk Telekom','Türk Telekom Eşimin Hattı':'Türk Telekom','Turkcell Hattım':'Turkcell'})){logos[name]=logos[source];sources[name]=sources[source];}
writeFileSync(new URL('../app/brand-logos.json',import.meta.url),JSON.stringify(logos));
writeFileSync(new URL('../public/logo-sources.json',import.meta.url),JSON.stringify(sources,null,2));
console.log(Object.keys(logos).length+' genuine logos embedded.');
