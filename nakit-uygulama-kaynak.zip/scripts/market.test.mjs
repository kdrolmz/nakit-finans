import assert from 'node:assert/strict';
import {parseStock,parseGold,quoteFresh,holdingValue,requestMarket} from '../app/market.ts';
const now=Date.parse('2026-09-09T12:44:30+03:00');
const stock=parseStock({data:[{s:'BIST:TUPRS',d:[411.75,4.37,17.25,'delayed_streaming_900',1788933600]}]},now);
assert.equal(stock.delay,900);assert.equal(stock.price,411.75);
assert.throws(()=>parseStock({data:[{s:'BIST:WRONG',d:[10,3]}]},now));
assert.throws(()=>parseStock({data:[{s:'BIST:TUPRS',d:[null,3]}]},now));
const gold=parseGold({Update_Date:'2026-09-09 12:44:01',GRA:{Buying:6850.72,Selling:6851.46,Change:.95},CEYREKALTIN:{Buying:10920.84,Selling:11172.31,Change:-.07}},now);
assert.equal(gold.GRAM.price,6850.72);assert.equal(gold.QUARTER.change,-.07);
assert.equal(quoteFresh(gold.GRAM,now+20*60000),false);
assert.equal(holdingValue({brand:'Tüpraş',kind:'saving',quantity:10,amount:4000},{TUPRS:stock},true,now),4117.5);
assert.equal(holdingValue({brand:'Tüpraş',kind:'saving',quantity:10,amount:4000},{TUPRS:{...stock,error:'offline'}},true,now),4000);
assert.equal(holdingValue({brand:'Tüpraş',kind:'saving',quantity:10,amount:4000},{TUPRS:stock},false,now),4000);
assert.equal(holdingValue({brand:'Gram Altın',kind:'saving',quantity:2.5,amount:10000},gold,true,now),17126.8);
if(process.argv.includes('--live')){const controller=new AbortController();const t=setTimeout(()=>controller.abort(),12000);const result=await requestMarket(controller.signal);clearTimeout(t);assert.deepEqual(Object.keys(result.errors),[]);assert.equal(Object.keys(result.quotes).length,3);console.log('Provider checks:',Object.values(result.quotes).map(q=>({instrument:q.instrument,price:q.price,source:q.source,delaySeconds:q.delay,sourceTime:q.sourceAt?new Date(q.sourceAt).toISOString():null})));}
console.log('Market validation passed: source schema, delays, gram/quarter mapping, quantities, stale fallback and historical separation.');
