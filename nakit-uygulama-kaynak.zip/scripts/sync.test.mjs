import assert from 'node:assert/strict';
import {emptyStore,mergeStores,validStore,SyncConflict} from '../app/sync-model.ts';
const record={id:991,kind:'expense',name:'Test faturası',brand:'BUSKİ',category:'home',amount:120,total:0,dueDay:15,start:'2026-09',end:'',recurring:true,note:'',payments:{},paymentMethod:'card'};
const base={...emptyStore(),records:[record]};
assert.ok(validStore(base));
const a=structuredClone(base),b=structuredClone(base);a.name='İsim';b.records[0].dueDay=20;
assert.equal(mergeStores(base,a,b).name,'İsim');assert.equal(mergeStores(base,a,b).records[0].dueDay,20);
const x=structuredClone(base),y=structuredClone(base);x.records[0].payments['2026-09']=120;y.records[0].payments['2026-10']=120;
assert.deepEqual(mergeStores(base,x,y).records[0].payments,{'2026-09':120,'2026-10':120});
x.records[0].name='A';y.records[0].name='B';assert.throws(()=>mergeStores(base,x,y),SyncConflict);
assert.throws(()=>mergeStores(base,{...base,records:[]},y),SyncConflict,'Delete vs edit must not silently lose data');
assert.equal(mergeStores(base,{...base,records:[]},base).records.length,0);
assert.equal(validStore({...base,records:[record,record]}),false,'Duplicate IDs rejected');
assert.equal(validStore({...base,records:[{...record,payments:{bad:1}}]}),false);
assert.equal(validStore({...base,records:[{...record,dueDays:{'2026-09':32}}]}),false);
console.log('Sync merge checks passed: independent edits, monthly payments, conflicts, deletion, validation.');
if(process.argv.includes('--api')){
 const endpoint='http://localhost:3000/api/finance';
 const headers={'Cookie':'__sites_local_auth=1','Content-Type':'application/json','Origin':'http://localhost:3000'};
 const get=async()=>{const r=await fetch(endpoint,{headers});assert.equal(r.status,200);return r.json();};
 const put=(store,revision,extra={})=>fetch(endpoint,{method:'PUT',headers:{...headers,...extra},body:JSON.stringify({store,revision})});
 assert.equal((await fetch(endpoint)).status,401,'Anonymous request rejected');
 assert.equal((await put(base,0,{Origin:'https://attacker.invalid'})).status,403,'Cross-origin write rejected');
 assert.equal((await put({version:2},0)).status,400,'Malformed data rejected');
 const initial=await get();assert.equal(initial.store.records.length,0,'Only use an empty local test database');
 let latest=initial;
 try{
  let response=await put(base,latest.revision);assert.equal(response.status,200);latest=await response.json();
  const deviceA=await get(),deviceB=await get();
  const editA=structuredClone(deviceA.store);editA.records[0].dueDay=9;
  response=await put(editA,deviceA.revision);assert.equal(response.status,200);latest=await response.json();
  assert.equal((await get()).store.records[0].dueDay,9,'Second client reads first client write');
  const editB=structuredClone(deviceB.store);editB.name='İkinci cihaz';
  assert.equal((await put(editB,deviceB.revision)).status,409,'Stale update rejected');
  const merged=mergeStores(deviceB.store,editB,latest.store);
  response=await put(merged,latest.revision);assert.equal(response.status,200);latest=await response.json();
  const final=await get();assert.equal(final.store.name,'İkinci cihaz');assert.equal(final.store.records[0].dueDay,9);
  console.log('Local API checks passed: authentication, CSRF, validation, two clients, conflict protection.');
 }finally{
  const response=await put(initial.store,latest.revision);assert.equal(response.status,200,'Restore local test state');
 }
}
