import type {RecordItem} from './finance';
export type Store={version:2;name:string;demo:boolean;records:RecordItem[]};
export type Snapshot={store:Store;revision:number;updatedAt:string|null};
export const emptyStore=():Store=>({version:2,name:'',demo:false,records:[]});
const monthPattern=/^\d{4}-(0[1-9]|1[0-2])$/;
export function validStore(s:unknown):s is Store {
 if(!s||typeof s!=='object')return false;
 const x=s as Store,amount=(v:unknown)=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=1e12;
 const ledger=(v:unknown,day=false)=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.entries(v).every(([k,n])=>monthPattern.test(k)&&amount(n)&&(!day||Number.isInteger(n)&&n>=1&&n<=31));
 return x.version===2&&typeof x.name==='string'&&x.name.length<=200&&typeof x.demo==='boolean'&&Array.isArray(x.records)&&x.records.length<=10000&&new Set(x.records.map(r=>r?.id)).size===x.records.length&&x.records.every(r=>r&&Number.isSafeInteger(r.id)&&r.id>0&&typeof r.name==='string'&&r.name.length<=200&&typeof r.brand==='string'&&r.brand.length<=200&&['income','expense','loan','creditCard','cashAdvance','debt','receivable','saving','subscription'].includes(r.kind)&&['platforms','home','shopping','loans','cards','advance','people','savings','income'].includes(r.category)&&amount(r.amount)&&amount(r.total)&&(r.quantity===undefined||amount(r.quantity)&&r.quantity>0)&&(r.costBasis===undefined||amount(r.costBasis))&&(r.paymentMethod===undefined||['cash','card'].includes(r.paymentMethod))&&(r.cardId===undefined||Number.isSafeInteger(r.cardId))&&(r.savingGroup===undefined||['liquid','pension','housing'].includes(r.savingGroup))&&Number.isInteger(r.dueDay)&&r.dueDay>=1&&r.dueDay<=31&&monthPattern.test(r.start)&&(!r.end||monthPattern.test(r.end))&&typeof r.recurring==='boolean'&&typeof r.note==='string'&&r.note.length<=10000&&ledger(r.payments)&&(!['loan','creditCard','cashAdvance','debt','receivable'].includes(r.kind)||Object.values(r.payments).reduce((s,n)=>s+Math.round(n*100),0)<=Math.round(r.total*100))&&(r.dueDays===undefined||ledger(r.dueDays,true)));
}
const equal=(a:unknown,b:unknown):boolean=>{
 if(a===b)return true;
 if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;
 const aa=a as Record<string,unknown>,bb=b as Record<string,unknown>;
 return Object.keys(aa).length===Object.keys(bb).length&&Object.keys(aa).every(k=>equal(aa[k],bb[k]));
};
export class SyncConflict extends Error {constructor(){super('Aynı kayıt iki cihazda farklı düzenlendi. Değişikliğin korunuyor; yeniden denemeden önce kontrol et.');}}
// Merge disjoint edits, including different payment months. Never silently replace a competing edit.
function mergeValue(base:unknown,local:unknown,remote:unknown):unknown {
 if(equal(local,base))return remote;
 if(equal(remote,base)||equal(local,remote))return local;
 if(base&&local&&remote&&[base,local,remote].every(v=>typeof v==='object'&&!Array.isArray(v))){
  const b=base as Record<string,unknown>,l=local as Record<string,unknown>,r=remote as Record<string,unknown>,out:Record<string,unknown>={};
  for(const k of new Set([...Object.keys(b),...Object.keys(l),...Object.keys(r)])){const v=mergeValue(b[k],l[k],r[k]);if(v!==undefined)out[k]=v;}
  return out;
 }
 throw new SyncConflict();
}
export function mergeStores(base:Store,local:Store,remote:Store):Store {
 const b=new Map(base.records.map(r=>[r.id,r])),l=new Map(local.records.map(r=>[r.id,r])),r=new Map(remote.records.map(r=>[r.id,r]));
 const records:RecordItem[]=[];
 for(const id of new Set([...r.keys(),...l.keys(),...b.keys()])){const record=mergeValue(b.get(id),l.get(id),r.get(id));if(record)records.push(record as RecordItem);}
 const result={version:2 as const,name:mergeValue(base.name,local.name,remote.name) as string,demo:mergeValue(base.demo,local.demo,remote.demo) as boolean,records};
 if(!validStore(result))throw new SyncConflict();
 return result;
}
