import {database} from '../../../db';
import {emptyStore,validStore} from '../../sync-model';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store, private','Vary':'Cookie'}});
export async function GET(request:Request){
 const user=request.headers.get('oai-authenticated-user-id');
 if(!user)return json({error:'Giriş gerekli.'},401);
 try{
  const row=await database().prepare('SELECT data, revision, updated_at FROM finance_accounts WHERE user_id = ?').bind(user).first<{data:string;revision:number;updated_at:string}>();
  return json({store:row?JSON.parse(row.data):emptyStore(),revision:row?.revision??0,updatedAt:row?.updated_at??null});
 }catch{return json({error:'Kayıt sunucusuna ulaşılamadı.'},503);}
}
export async function PUT(request:Request){
 const user=request.headers.get('oai-authenticated-user-id');
 if(!user)return json({error:'Giriş gerekli.'},401);
 // Same-origin JSON writes only. Identity is injected by the private Sites dispatcher.
 if(request.headers.get('origin')!==new URL(request.url).origin||!request.headers.get('content-type')?.startsWith('application/json'))return json({error:'Geçersiz istek.'},403);
 try{
  const raw=await request.text();if(raw.length>2_000_000)return json({error:'Kayıt boyutu sınırı aşıldı.'},413);
  const body=JSON.parse(raw);if(!validStore(body.store)||!Number.isSafeInteger(body.revision)||body.revision<0)return json({error:'Geçersiz kayıt.'},400);
  const db=database(),now=new Date().toISOString(),data=JSON.stringify(body.store);
  const result=body.revision===0?
   await db.prepare('INSERT INTO finance_accounts (user_id,data,revision,updated_at) VALUES (?,?,1,?) ON CONFLICT(user_id) DO NOTHING').bind(user,data,now).run():
   await db.prepare('UPDATE finance_accounts SET data = ?, revision = revision + 1, updated_at = ? WHERE user_id = ? AND revision = ?').bind(data,now,user,body.revision).run();
  if(!result.meta.changes)return json({error:'Başka cihazda güncellendi.'},409);
  return json({store:body.store,revision:body.revision+1,updatedAt:now});
 }catch{return json({error:'Kayıt kaydedilemedi.'},503);}
}
