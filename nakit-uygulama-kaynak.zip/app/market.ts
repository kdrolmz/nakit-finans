export type Instrument='TUPRS'|'GRAM'|'QUARTER';
export type Quote={instrument:Instrument;price:number;sell?:number;change:number;checkedAt:number;sourceAt?:number;delay:number|null;source:string;url:string;error?:string};
export type Quotes=Partial<Record<Instrument,Quote>>;
export const instrumentFor=(brand:string):Instrument|undefined=>brand==='Tüpraş'?'TUPRS':brand==='Gram Altın'?'GRAM':brand==='Çeyrek Altın'?'QUARTER':undefined;
export const instrumentName={TUPRS:'TUPRS',GRAM:'Gram altın',QUARTER:'Çeyrek altın'};
export function parseStock(data:unknown,now=Date.now()):Quote {
 const d=(data as {data?:{s:string;d:unknown[]}[]})?.data?.find(x=>x.s==='BIST:TUPRS')?.d;
 if(!d||typeof d[0]!=='number'||!Number.isFinite(d[0])||d[0]<=0||typeof d[1]!=='number'||!Number.isFinite(d[1]))throw Error('TUPRS fiyatı doğrulanamadı.');
 const mode=String(d[3]);const match=mode.match(/delayed_streaming_(\d+)/);
 return {instrument:'TUPRS',price:d[0],change:d[1],checkedAt:now,sourceAt:typeof d[4]==='number'?d[4]*1000:undefined,delay:match?Number(match[1]):mode==='streaming'?0:null,source:'TradingView',url:'https://www.tradingview.com/symbols/BIST-TUPRS/'};
}
export function parseGold(data:unknown,now=Date.now()):Quotes {
 const d=data as Record<string,unknown>;const stamp=String(d.Update_Date||'');const sourceAt=Date.parse(stamp.replace(' ','T')+'+03:00');
 if(!Number.isFinite(sourceAt)||sourceAt>now+300000)throw Error('Altın güncelleme tarihi doğrulanamadı.');
 const result:Quotes={};
 for(const [key,id] of [['GRA','GRAM'],['CEYREKALTIN','QUARTER']] as const){const value=d[key] as {Buying:number;Selling:number;Change:number};if(!value||![value.Buying,value.Selling,value.Change].every(Number.isFinite)||value.Buying<=0||value.Selling<=0||value.Buying>value.Selling)throw Error('Altın alış/satış verisi doğrulanamadı.');result[id]={instrument:id,price:value.Buying,sell:value.Selling,change:value.Change,sourceAt,checkedAt:now,delay:null,source:'Trunçgil Finans',url:'https://finans.truncgil.com/'};}
 return result;
}
export const quoteFresh=(q:Quote,now=Date.now())=>!q.error&&now-q.checkedAt<150000&&(q.instrument==='TUPRS'||!!q.sourceAt&&now-q.sourceAt<15*60000);
export function holdingValue(r:{brand:string;kind:string;quantity?:number;amount:number},quotes:Quotes,currentMonth:boolean,now=Date.now()) {const id=instrumentFor(r.brand),q=id?quotes[id]:undefined;return r.kind==='saving'&&r.quantity&&q&&quoteFresh(q,now)&&currentMonth?Math.round(r.quantity*q.price*100)/100:r.amount;}
export async function requestMarket(signal:AbortSignal):Promise<{quotes:Quotes;errors:Partial<Record<Instrument,string>>}> {
 const results=await Promise.allSettled([
  fetch('https://scanner.tradingview.com/turkey/scan',{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify({symbols:{tickers:['BIST:TUPRS']},columns:['close','change','change_abs','update_mode','time']}),credentials:'omit',signal}).then(async r=>{if(!r.ok)throw Error('TUPRS kaynağı yanıt vermiyor.');return parseStock(await r.json());}),
  fetch('https://finans.truncgil.com/v4/today.json?_='+Math.floor(Date.now()/60000),{cache:'no-store',credentials:'omit',signal}).then(async r=>{if(!r.ok)throw Error('Altın kaynağı yanıt vermiyor.');return parseGold(await r.json());})
 ]);
 const quotes:Quotes={},errors:Partial<Record<Instrument,string>>={};
 if(results[0].status==='fulfilled')quotes.TUPRS=results[0].value;else errors.TUPRS='Fiyat alınamadı. Yeniden denenecek.';
 if(results[1].status==='fulfilled')Object.assign(quotes,results[1].value);else{errors.GRAM='Fiyat alınamadı. Yeniden denenecek.';errors.QUARTER=errors.GRAM;}
 return {quotes,errors};
}
