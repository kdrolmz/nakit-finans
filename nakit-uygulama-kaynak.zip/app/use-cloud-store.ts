'use client';
import {useCallback,useEffect,useRef,useState,type SetStateAction} from 'react';
import {emptyStore,mergeStores,validStore,SyncConflict,type Store,type Snapshot} from './sync-model';
import {migrateLegacy,monthKey} from './finance';
type Status='loading'|'saving'|'synced'|'error';
const pendingKey='nakit-pending-sync-v1';
async function request(method='GET',body?:unknown):Promise<Snapshot>{
 const response=await fetch('/api/finance',{method,credentials:'same-origin',cache:'no-store',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(15000)});
 if(response.status===409)throw new Error('conflict');
 if(response.status===401)throw new Error('Aynı ChatGPT hesabıyla giriş yapmalısın.');
 if(!response.ok)throw new Error('Sunucuya ulaşılamadı. Değişiklik henüz diğer cihaza aktarılmadı.');
 const snapshot=await response.json() as Snapshot;
 if(!validStore(snapshot.store)||!Number.isSafeInteger(snapshot.revision))throw new Error('Sunucu yanıtı doğrulanamadı.');
 return snapshot;
}
export function useCloudStore(){
 const [store,renderStore]=useState<Store>(emptyStore),[ready,setReady]=useState(false),[status,setStatus]=useState<Status>('loading'),[error,setError]=useState(''),[updatedAt,setUpdatedAt]=useState<string|null>(null);
 const [conflicted,setConflicted]=useState(false);
 const conflict=useRef(false),current=useRef(store),base=useRef<Snapshot|null>(null),dirty=useRef(false),busy=useRef(false),mounted=useRef(false),timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 const show=useCallback((value:Store)=>{current.current=value;renderStore(value);},[]);
 const persistDraft=useCallback(()=>{if(base.current)try{localStorage.setItem(pendingKey,JSON.stringify({base:base.current.store,local:current.current}));}catch{/* Visible save status remains authoritative. */}},[]);
 const sync=useCallback(async()=>{
  if(busy.current||!base.current||conflict.current)return;
  busy.current=true;
  try{
   if(dirty.current){
    setStatus('saving');setError('');
    const submitted=current.current;let candidate=submitted,expected=base.current;
    let saved:Snapshot|undefined;
    for(let attempt=0;attempt<4;attempt++){
     try{saved=await request('PUT',{store:candidate,revision:expected.revision});break;}
     catch(e){if((e as Error).message!=='conflict')throw e;const latest=await request();candidate=mergeStores(expected.store,candidate,latest.store);expected=latest;}
    }
    if(!saved)throw new Error('Diğer cihazda güncelleme sürüyor. Yeniden dene.');
    if(!mounted.current)return;
    const followup=current.current!==submitted;
    const next=followup?mergeStores(submitted,current.current,saved.store):saved.store;
    base.current=saved;dirty.current=followup;show(next);setUpdatedAt(saved.updatedAt);
    if(followup){persistDraft();setStatus('saving');}else{try{localStorage.removeItem(pendingKey);}catch{}setStatus('synced');}
   }else{
    const latest=await request();if(!mounted.current)return;
    // A user may have edited while the read was in flight. Do not replace that draft.
    if(!dirty.current){base.current=latest;show(latest.store);setUpdatedAt(latest.updatedAt);setStatus('synced');setError('');}
   }
  }catch(e){if(mounted.current){if(e instanceof SyncConflict){conflict.current=true;setConflicted(true);}setStatus('error');setError((e as Error).message==='conflict'?'Başka cihazda güncellendi. Yeniden dene.':(e as Error).message);if(dirty.current)persistDraft();}}
  finally{busy.current=false;}
 },[show,persistDraft]);
 useEffect(()=>{
  mounted.current=true;
  const initialize=async()=>{
   try{
    const remote=await request();if(!mounted.current)return;
    base.current=remote;show(remote.store);let value=remote.store;
    const pending=localStorage.getItem(pendingKey);
    if(pending){const p=JSON.parse(pending);if(validStore(p.base)&&validStore(p.local)){value=p.local;dirty.current=true;show(value);value=mergeStores(p.base,p.local,remote.store);}}
    else if(remote.revision===0){
     const old=localStorage.getItem('nakit-premium-v2'),v1=localStorage.getItem('nakit-premium-v1');
     if(old){const parsed=JSON.parse(old);if(validStore(parsed)&&!parsed.demo){value=parsed;dirty.current=true;}}
     else if(v1){const parsed=JSON.parse(v1);if(Array.isArray(parsed)){const migrated={version:2 as const,name:'',demo:false,records:migrateLegacy(parsed,monthKey())};if(validStore(migrated)){value=migrated;dirty.current=true;}}}
    }
    show(value);setUpdatedAt(remote.updatedAt);setReady(true);setStatus(dirty.current?'saving':'synced');
    if(dirty.current){persistDraft();void sync();}
   }catch(e){if(mounted.current){if(e instanceof SyncConflict){conflict.current=true;setConflicted(true);}setError((e as Error).message);setStatus('error');setReady(!!base.current);}}
  };
  void initialize();
  const poll=setInterval(()=>void sync(),5000);
  const refresh=()=>{if(document.visibilityState==='visible')void (base.current?sync():initialize());};
  window.addEventListener('online',refresh);document.addEventListener('visibilitychange',refresh);
  const warn=(e:BeforeUnloadEvent)=>{if(dirty.current){e.preventDefault();e.returnValue='';}};
  window.addEventListener('beforeunload',warn);
  return()=>{mounted.current=false;clearInterval(poll);if(timer.current)clearTimeout(timer.current);window.removeEventListener('online',refresh);document.removeEventListener('visibilitychange',refresh);window.removeEventListener('beforeunload',warn);};
 },[show,persistDraft,sync]);
 const setStore=useCallback((action:SetStateAction<Store>)=>{
  if(!base.current||conflict.current){setError('Önce senkronizasyon uyarısını çözmelisin.');return;}
  const value=typeof action==='function'?action(current.current):action;
  show(value);dirty.current=true;setStatus('saving');persistDraft();
  if(timer.current)clearTimeout(timer.current);timer.current=setTimeout(()=>void sync(),450);
 },[show,persistDraft,sync]);
 const discard=async()=>{try{const latest=await request();base.current=latest;dirty.current=false;conflict.current=false;setConflicted(false);show(latest.store);setUpdatedAt(latest.updatedAt);localStorage.removeItem(pendingKey);setError('');setStatus('synced');}catch(e){setError((e as Error).message);}};
 return {store,setStore,ready,status,error,updatedAt,conflicted,discard,retry:()=>{if(!base.current)location.reload();else void sync();}};
}
