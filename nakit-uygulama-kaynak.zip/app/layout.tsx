import type { Metadata, Viewport } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#ffffff' };

export const metadata: Metadata = {
  metadataBase: new URL('https://nakit-premium-finans.black-pine-4169.chatgpt.site'),
  title: 'Nakit — Premium Finans Takibi',
  description: 'Gelir, gider, borç, kredi, kart, abonelik ve birikimlerinizi tek ekranda yönetin.',
  openGraph: {
    title: 'Nakit — Premium Finans Takibi',
    description: 'Finansının tamamı. Tek bir yerde.',
    images: [{ url: '/og.png', width: 1200, height: 630, alt: 'Nakit premium finans takip uygulaması' }],
    locale: 'tr_TR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nakit — Premium Finans Takibi',
    description: 'Finansının tamamı. Tek bir yerde.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
