export type Kind = 'income' | 'expense' | 'loan' | 'creditCard' | 'cashAdvance' | 'debt' | 'receivable' | 'saving' | 'subscription';
export type SavingGroup = 'liquid' | 'pension' | 'housing';
export type RecordItem = { id: number; kind: Kind; name: string; brand: string; category: string; amount: number; total: number; dueDay: number; start: string; end: string; recurring: boolean; note: string; payments: Record<string, number>; quantity?:number;costBasis?:number;paymentMethod?:'cash'|'card';cardId?:number;savingGroup?:SavingGroup;dueDays?:Record<string,number> };
export const savingGroups = [
 {id:'liquid',title:'Altın & Borsa',description:'Nakde çevrilebilir yatırımlar',icon:'gem'},
 {id:'pension',title:'Bireysel Emeklilik',description:'Uzun vadeli emeklilik birikimleri',icon:'lock'},
 {id:'housing',title:'Ev Finansmanı',description:'Konut için ayrılan birikimler',icon:'home'},
] as const;
export function savingGroupFor(r:Pick<RecordItem,'brand'|'savingGroup'>):SavingGroup {
 if(r.savingGroup)return r.savingGroup;
 if(/eminevim|emin evim/i.test(r.brand))return 'housing';
 return /emeklilik|anadolu hayat|allianz|agesa/i.test(r.brand)?'pension':'liquid';
}
export function scheduledDay(r:RecordItem,month:string){return Math.min(r.dueDays?.[month]??r.dueDay,new Date(Number(month.slice(0,4)),Number(month.slice(5)),0).getDate());}
export function setScheduledDay(r:RecordItem,month:string,day:number):RecordItem {
 if(!Number.isInteger(day)||day<1||day>31)throw Error('Ödeme günü 1–31 arasında olmalı.');
 return {...r,dueDays:{...r.dueDays,[month]:day}};
}
export function monthlyExpenses(records:RecordItem[],month:string){return records.filter(r=>isCashExpense(r)&&due(r,month)>0).sort((a,b)=>scheduledDay(a,month)-scheduledDay(b,month)||a.id-b.id);}
export const categories = [
  { id: 'platforms', title: 'Platformlar', description: 'Dijital abonelikler', icon: 'play', color: '#bda8ef', kind: 'subscription' },
  { id: 'home', title: 'Ev giderleri', description: 'Kira, aidat ve faturalar', icon: 'home', color: '#9bb7d4', kind: 'expense' },
  { id: 'shopping', title: 'Alışveriş', description: 'Market, giyim ve diğer', icon: 'bag', color: '#d9afa0', kind: 'expense' },
  { id: 'loans', title: 'Banka kredileri', description: 'Taksitler ve kalan borç', icon: 'bank', color: '#d5bc85', kind: 'loan' },
  { id: 'cards', title: 'Kredi kartları', description: 'Ekstreler ve ödemeler', icon: 'card', color: '#a9b5d9', kind: 'creditCard' },
  { id: 'advance', title: 'Nakit avans', description: 'Taksitli nakit avanslar', icon: 'wallet', color: '#b6c9b0', kind: 'cashAdvance' },
  { id: 'people', title: 'Borç & alacak', description: 'Arkadaşlar ve aile', icon: 'people', color: '#d5a8c1', kind: 'debt' },
  { id: 'savings', title: 'Birikimler', description: 'Altın, borsa ve emeklilik', icon: 'gem', color: '#dcc28c', kind: 'saving' },
  { id: 'income', title: 'Gelirler', description: 'Maaş ve diğer gelirler', icon: 'income', color: '#9fcab7', kind: 'income' },
] as const;
export const labels: Record<Kind,string> = {income:'Gelir',expense:'Gider',loan:'Kredi',creditCard:'Kredi kartı',cashAdvance:'Nakit avans',debt:'Borç',receivable:'Alacak',saving:'Birikim',subscription:'Abonelik'};
export const isExpense = (r:RecordItem) => !['income','receivable','saving'].includes(r.kind);
export const isCardCharge = (r:RecordItem) => ['subscription','expense'].includes(r.kind)&&r.paymentMethod==='card';
export const isCashExpense = (r:RecordItem) => isExpense(r)&&!isCardCharge(r);
export const isDebt = (r:RecordItem) => ['loan','creditCard','cashAdvance','debt','receivable'].includes(r.kind);
export const cents = (n:number) => Math.round(n*100);
export const round = (n:number) => cents(n)/100;
export const monthKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
export function shiftMonth(key:string, by:number) { const [y,m]=key.split('-').map(Number); return monthKey(new Date(y,m-1+by,1)); }
export function monthName(key:string) { const [y,m]=key.split('-').map(Number); return new Date(y,m-1,1).toLocaleDateString('tr-TR',{month:'long',year:'numeric'}); }
export function active(r:RecordItem, month:string) { return r.kind==='saving' ? r.start<=month : r.start<=month && (!r.end || month<=r.end) && (r.recurring || r.start===month); }
export function paidBefore(r:RecordItem,month:string) { return round(Object.entries(r.payments).filter(([m])=>m<month).reduce((s,[,a])=>s+a,0)); }
export function due(r:RecordItem,month:string) { if(!active(r,month)) return 0; if(isDebt(r)) return round(Math.min(r.amount,Math.max(0,r.total-paidBefore(r,month)))); return r.amount; }
export function paid(r:RecordItem,month:string) { return Math.min(due(r,month),r.payments[month]||0); }
export function outstanding(r:RecordItem,month:string) { return round(Math.max(0,r.total-Object.entries(r.payments).filter(([m])=>m<=month).reduce((s,[,a])=>s+a,0))); }
export function togglePayment(r:RecordItem,month:string):RecordItem {
 const amount=due(r,month); if(amount<=0)return r;
 const payments={...r.payments};
 if(paid(r,month)>=amount)delete payments[month];
 else {const other=Object.entries(payments).filter(([m])=>m!==month).reduce((s,[,a])=>s+cents(a),0);if(isDebt(r)&&other+cents(amount)>cents(r.total))throw Error('Sonraki aylara ödeme kaydedilmiş. Toplam borcu aşmamak için önce o ödemeleri geri al.');payments[month]=amount;}
 return {...r,payments};
}
export function summary(records:RecordItem[],month:string) {
  const sum=(fn:(r:RecordItem)=>number)=>round(records.reduce((s,r)=>s+fn(r),0));
  const expense=sum(r=>isCashExpense(r)?due(r,month):0), expensePaid=sum(r=>isCashExpense(r)?paid(r,month):0);
  const income=sum(r=>r.kind==='income'?due(r,month):0), received=sum(r=>['income','receivable'].includes(r.kind)?paid(r,month):0);
  const assets=sum(r=>r.kind==='saving'&&active(r,month)?r.amount:0), debt=sum(r=>isDebt(r)&&r.kind!=='receivable'&&r.start<=month?outstanding(r,month):0);
  const receivable=sum(r=>r.kind==='receivable'&&r.start<=month?outstanding(r,month):0);
  return {expense,expensePaid,income,received,assets,debt,receivable,remaining:round(expense-expensePaid),net:round(income-expense),cash:round(received-expensePaid)};
}
export function parseAmount(input:string) { const t=input.trim().replace(/\s/g,''); if(!t) return NaN; const normalized=t.includes(',')?t.replace(/\./g,'').replace(',','.'):t; return /^\d+(\.\d{1,2})?$/.test(normalized)?round(Number(normalized)):NaN; }
export const catalog:Record<string,string[]>={
 platforms:['Netflix','YouTube Premium','Amazon Prime','Max / HBO','Disney+','Spotify','Apple Music','Canva Pro','ChatGPT Plus','Claude','Adobe CC','iCloud+','Google One','Microsoft 365','Exxen','GAIN','MUBI','TOD','beIN Connect'],
 banks:['Garanti BBVA','Akbank','Yapı Kredi','İş Bankası','Ziraat Bankası','Halkbank','VakıfBank','QNB','DenizBank','TEB','ING','Enpara','Kuveyt Türk','Fibabanka','Odeabank'],
 home:['Ev Kirası','Site Aidatı','BUSKİ','Uludağ Elektrik','Türk Telekom İnternet','Turkcell Hattım','Türk Telekom Eşimin Hattı','Elektrik','Su','Doğalgaz','İnternet','Telefon','Ev sigortası'],
 shopping:['Market','Giyim','Elektronik','Ulaşım','Yeme & içme','Sağlık','Diğer alışveriş'],
 people:['Arkadaş / Aile'],savings:['Gram Altın','Çeyrek Altın','Borsa İstanbul','Tüpraş','Garanti Emeklilik','Türkiye Hayat Emeklilik','Anadolu Hayat','Allianz Yaşam','AgeSA','Eminevim','Yatırım Fonu','Döviz','Vadeli Mevduat'],income:['Maaş','Ek gelir','Kira geliri','Diğer gelir']
};
export function catalogFor(category:string){return catalog[['loans','cards','advance'].includes(category)?'banks':category]||[];}
export function sampleRecords(month:string):RecordItem[]{
 const specs:[Kind,string,string,string,number,number,number][]=[
 ['income','Maaş','Maaş','income',85000,0,1],['expense','Ev kirası','Ev Kirası','home',22000,0,5],['expense','Site aidatı','Site Aidatı','home',1800,0,10],['expense','Elektrik faturası','Elektrik','home',780,0,18],
 ['subscription','Netflix Premium','Netflix','platforms',399.99,0,12],['subscription','YouTube Premium','YouTube Premium','platforms',99.99,0,16],['subscription','Canva Pro','Canva Pro','platforms',499,0,22],['subscription','Amazon Prime','Amazon Prime','platforms',69.9,0,24],
 ['loan','İhtiyaç kredisi','Garanti BBVA','loans',8500,153000,15],['creditCard','Axess kartım','Akbank','cards',12500,34500,20],['cashAdvance','Taksitli nakit avans','Yapı Kredi','advance',3000,18000,25],
 ['debt','Ege’ye borcum','Arkadaş / Aile','people',2500,10000,28],['receivable','Can’dan alacağım','Arkadaş / Aile','people',5000,5000,20],['expense','Market alışverişi','Market','shopping',3250,0,8],
 ['saving','Altın birikimim','Gram Altın','savings',95000,0,1],['saving','TUPRS hisseleri','Tüpraş','savings',48500,0,1],['saving','Garanti BES','Garanti Emeklilik','savings',72400,0,1],['saving','Türkiye Hayat BES','Türkiye Hayat Emeklilik','savings',38000,0,1]
 ];
 return specs.map(([kind,name,brand,category,amount,total,dueDay],i)=>({id:i+1,kind,name,brand,category,amount,total,dueDay,start:month,end:['loan','cashAdvance','debt'].includes(kind)?shiftMonth(month,Math.ceil(total/amount)-1):'',recurring:!['creditCard','receivable'].includes(kind)&&category!=='shopping',note:'Örnek kayıt; kendi bilgilerinle düzenleyebilirsin.',payments: i===0||i===1||i===13?{[month]:amount}:{}}));
}
export function migrateLegacy(old:Record<string,unknown>[], month:string):RecordItem[]{return old.map((r,i)=>{const kind=r.kind as Kind; const category=kind==='subscription'?'platforms':kind==='saving'?'savings':kind==='income'?'income':kind==='loan'?'loans':kind==='creditCard'?'cards':kind==='cashAdvance'?'advance':['debt','receivable'].includes(kind)?'people':'home';return {id:Number(r.id)||i+1,kind,name:String(r.name||'Kayıt'),brand:String(r.brand||''),category,amount:Number(r.monthly||r.amount)||0,total:Number(r.total||r.amount)||0,dueDay:Number(r.dueDay)||1,start:month,end:String(r.endDate||''),recurring:!['creditCard','receivable'].includes(kind),note:String(r.note||''),payments:r.paid?{[month]:Number(r.monthly||r.amount)||0}:{}};});}
